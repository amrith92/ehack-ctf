<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title>thegeekmachine</title>
</head><body><h1>It works!</h1>
<p>This is the default web page for this server.</p>
<p><strike>The web server software is running but no content has been added, yet.</strike> <em>Bullshit.</em></p>
<hr />
<p>Here&apos;s all you need to know about this server:</p>
<pre>
<?php
	echo var_export($_SERVER, true);
?>
</pre>
</body></html>
